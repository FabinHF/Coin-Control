import Footer from "./components/Footer"
import Navbar from "./components/navbar"
import {BrowserRouter} from 'react-router'


function App() {
  let sla = false
  return (
    <>
      <BrowserRouter>
        <Navbar logado={sla} />

        <Footer/>
      </BrowserRouter>
    </>
  )
}

export default App
